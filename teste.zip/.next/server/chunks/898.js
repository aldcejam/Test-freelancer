"use strict";
exports.id = 898;
exports.ids = [898];
exports.modules = {

/***/ 898:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RegulationComponent)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function RegulationComponent() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: "text-3xl mb-7",
                children: "Regulamento"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "block py-5 pl-6 w-56 bg-lightBlue border-l-DarkBlue border-l-8 border-solid ",
                                        href: "",
                                        children: "O que est\xe1 incluso"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "block shadow-3xl py-5 pl-6 w-56 mt-3 border-l-DarkBlue border-l-8 border-solid ",
                                        href: "",
                                        children: "Como utilizar"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "block shadow-3xl py-5 pl-6 w-56 mt-3 border-l-blue border-l-8 border-solid ",
                                        href: "",
                                        children: "Cancelamento e taxas"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "block shadow-3xl py-5 pl-6 w-56 mt-3 border-l-blue border-l-8 border-solid ",
                                        href: "",
                                        children: "Hotel e comodidades"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "block shadow-3xl py-5 pl-6 w-56 mt-3 border-l-blue border-l-8 border-solid ",
                                        href: "",
                                        children: "Regulamento Completo"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "px-10 text-text",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "",
                                children: "Conhe\xe7a o pacote"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                children: "o pacote inclui:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "A\xe9reo: Passagem a\xe9rea de ida e volta entre a cidade de origem Campo Grande - Aeroporto Internacional de Campo Grande (CGR), em classe econ\xf4mica, podendo haver conex\xe3o e/ou escala."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Bagagem: Este pacote permite levar uma bagagem de m\xe3o com at\xe9 10 quilos. Desta forma, voc\xea poder\xe1 levar uma mochila ou bolsa (que dever\xe1 ser acomodada debaixo do seu assento) e uma bagagem de m\xe3o (que dever\xe1 caber no compartimento superior do avi\xe3o). "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Hospedagem: Em Bonito na Pousada Caramanch\xe3o, Pousada Ch\xe3o de Pedra, Pousada Flor da Guavira, Pousada Lago Azul ou outro hotel de mesma categoria econ\xf4mica - com caf\xe9 da manh\xe3. A hospedagem ser\xe1 definida pelo Hurb de acordo com a disponibilidade e tarif\xe1rio promocional. "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Aten\xe7\xe3o: As di\xe1rias s\xe3o contabilizadas pelas noites dormidas a partir da sua chegada no hotel."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Idiomas do hotel: Portugu\xeas, ingl\xeas ou espanhol"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-2xl",
                                children: "Dados do Voo"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "N\xf3s ficamos respons\xe1veis por escolher as informa\xe7\xf5es do seu voo (aeroporto, companhia a\xe9rea, dias e hor\xe1rios de voo). Estas informa\xe7\xf5es ser\xe3o enviadas para sua confirma\xe7\xe3o em at\xe9 45 dias antes da primeira data que voc\xea inseriu no formul\xe1rio."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-2xl",
                                children: "Tipo de Acomoda\xe7\xe3o"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Quarto individual, duplo ou triplo, de acordo com o n\xfamero de viajantes."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-2xl",
                                children: "Importante"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Para garantir a oferta no precinho Hurb, voc\xea deve comprar 2 pacotes para validar a acomoda\xe7\xe3o dupla ou 3 pacotes para validar a acomoda\xe7\xe3o tripla."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Se desejar, poder\xe1 configurar acomoda\xe7\xe3o individual ao comprar apenas 1 pacote. Essa informa\xe7\xe3o dever\xe1 ser inserida no campo Solicita\xe7\xf5es Especiais do formul\xe1rio de agendamento. Ser\xe1 adicionado 40% do valor da op\xe7\xe3o escolhida antes da emiss\xe3o da passagem a\xe9rea. N\xe3o ser\xe1 poss\xedvel validar o pacote sem o pagamento dessa diferen\xe7a. "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                children: "Regra para vincular os pacotes:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Caso tenha comprado seu pacote separado das pessoas que viajar\xe3o com voc\xea, o n\xfamero do pedido de cada um dever\xe1 ser informado no formul\xe1rio de agendamento dos outros integrantes para agilizar o processo de reserva de todos."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Obs.: Nem sempre conseguimos garantir o mesmo voo e/ou hotel para todos os viajantes com pedidos vinculados. Vai depender do n\xfamero de viajantes e da disponibilidade. Caso deseje que todos estejam no mesmo voo e/ou hotel, nos informe no campo  Viajando com outras pessoas\u201D, o n\xfamero dos pedidos dos outros viajantes para verificarmos a disponibilidade."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                children: "Pagamentos:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Para finalizar a compra do seu pacote, voc\xea pode optar por pagar em at\xe9 12x no cart\xe3o de cr\xe9dito ou no boleto banc\xe1rio \xe0 vista. Se desejar pagar no boleto parcelado, sem consulta ao SPC e SERASA, voc\xea poder\xe1 consultar o n\xfamero de parcelas dispon\xedveis na p\xe1gina de pagamento, antes de finalizar a compra.  "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Aten\xe7\xe3o para o per\xedodo em que deseja viajar, pois o pagamento em boleto parcelado dever\xe1 ser conclu\xeddo com, no m\xednimo, 60 dias de anteced\xeancia do per\xedodo em que deseja efetivar a sua viagem."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                children: "Fique Ligado(a)!"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "O n\xe3o pagamento de algum boleto em at\xe9 10 dias ap\xf3s a compra resulta no cancelamento autom\xe1tico do pedido."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "\xc9 legal saber: em alguns casos, \xe9 poss\xedvel que seja cobrado juros de parcelamento. Voc\xea pode conferir esses detalhes antes do pagamento por boleto ou cart\xe3o de cr\xe9dito. Aten\xe7\xe3o!"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                children: "- O Hurb n\xe3o realiza personaliza\xe7\xf5es/modifica\xe7\xf5es nos pacotes;"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "- Caso as 3 datas sugeridas pelo Viajante estejam indispon\xedveis, iremos enviar uma nova op\xe7\xe3o levando em considera\xe7\xe3o a proximidade \xe0s datas sugeridas;"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "- Garantimos o mesmo voo para at\xe9 8 viajantes com pedidos vinculados. No entanto, a hospedagem ir\xe1 depender da disponibilidade do estabelecimento."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-2xl",
                                children: "Regras para Crian\xe7as"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Crian\xe7as de at\xe9 1 ano e 11 meses completos at\xe9 a data de retorno da viagem pagam uma taxa de servi\xe7o de 150 reais. Esse valor poder\xe1 ser pago antes da confirma\xe7\xe3o do voo atrav\xe9s do link abaixo. Os dados da crian\xe7a (nome completo e data de nascimento) dever\xe3o ser informados no campo \u201CSolicita\xe7\xf5es sobre sua viagem\u201D do formul\xe1rio de agendamento. Link para taxa de servi\xe7o infantil: https://www.hurb.com/br/packages/especial/868793 "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "\u2022 Crian\xe7as a partir de 2 anos pagam o mesmo valor de adulto, sendo necess\xe1ria a compra do pacote para a mesma"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};


/***/ })

};
;